#include <Arduino.h>

#include <string>

#include <WiFi.h>

#include <Firebase_ESP_Client.h>

//Provide the token generation process info.
#include "addons/TokenHelper.h"
//Provide the RTDB payload printing info and other helper functions.
#include "addons/RTDBHelper.h"

// Insert your network credentials
#define WIFI_SSID "J2_4"
#define WIFI_PASSWORD "Ciri@1234"

// Insert Firebase project API Key
#define API_KEY "AIzaSyCRrtmfL_RdnZYQ_A5gMf1AsHkzVUgJN3M"

// Insert RTDB URLefine the RTDB URL */
#define DATABASE_URL "greenhouse-6eb49-default-rtdb.firebaseio.com/" 

// #define USER_EMAIL "haseeb.kollorath@gmail.com"

// #define USER_PASSWORD "123456"
//Define Firebase Data object
FirebaseData fbdo;

FirebaseAuth auth;
FirebaseConfig config;

unsigned long sendDataPrevMillis = 0;
int count = 0;
bool signupOK = false;



// moisture sensor calliberation
int moisture_percent;
int sensor_raw;
#define SENSOR_IN 36 // put pin for soil moisture sensor
// SM1
// #define SENSOR_DRY 3050
// #define SENSOR_WET 2150

// SM2
#define SENSOR_DRY 2750
#define SENSOR_WET 950

void soilMoistureMeasure();

// setting local pump trigger
int pump_trigger = 30;
bool pump_status;
char updated_trigger[5];

// change pump status based on moisture level and trigger level
void pumpControl();

// get and update value to and from firebase
void updateFirebase();

// update local trigger level with trigger level from firebase
void updateTrigger();



// DHT sensor library - Version: Latest
#include <DHT.h>
#include <DHT_U.h>

#define DHTPIN 26
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);
float temperature;
float humidity;

void getDHT();







#define SLEEP_DURATION 5 // 21600 sec - 6 hrs

void lightSleep();





// MOTOR
#define MOTOR_PIN 25
void pumpOn();
void pumpOff();


void setup(){
  Serial.begin(921600);

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to Wi-Fi");
  while (WiFi.status() != WL_CONNECTED){
    Serial.print(".");
    delay(300);
  }
  Serial.println();
  Serial.print("Connected with IP: ");
  Serial.println(WiFi.localIP());
  Serial.println();

  /* Assign the api key (required) */
  config.api_key = API_KEY;

  /* Assign the RTDB URL (required) */
  config.database_url = DATABASE_URL;

  /* Sign up */
  if (Firebase.signUp(&config, &auth, "", "")){
    Serial.println("ok");
    signupOK = true;
  }
  else{
    Serial.printf("%s\n", config.signer.signupError.message.c_str());
  }

  /* Assign the callback function for the long running token generation task */
  config.token_status_callback = tokenStatusCallback; //see addons/TokenHelper.h
  
  Firebase.begin(&config, &auth);
  Firebase.reconnectWiFi(true);

  dht.begin();

  soilMoistureMeasure();

  pump_status = false;

  pinMode(MOTOR_PIN, OUTPUT);
}

void loop(){

  delay(2000);

  getDHT();

  soilMoistureMeasure();

  updateFirebase();

  updateTrigger();

  pumpControl();
  
  Serial.print("\n\nRaw Moisture: "+String(sensor_raw));
  Serial.print("\nMoisture: "+String(moisture_percent)+"%");
  Serial.print("\nPump Trigger: "+String(pump_trigger));
  Serial.print("\nPump Status: "+String(pump_status));
  Serial.print("\nUpdated Pump Trigger: "+String(updated_trigger));
  Serial.print("\nTemperature: "+String(temperature)+"°C");
  Serial.print("\nHumidity: "+String(humidity)+"%");

}

void soilMoistureMeasure(){
  sensor_raw = analogRead(SENSOR_IN);
  moisture_percent = map(sensor_raw, SENSOR_DRY, SENSOR_WET, 0, 100);
  moisture_percent = constrain(moisture_percent, 0, 100);
}

void pumpControl(){
  if (moisture_percent < pump_trigger){
    pump_status = true;
    // watering for 3 second
    pumpOn();
    pumpOff();



    // water for 3 seconds and go to sleep
    Serial.println("\tGoing to sleep...");
    delay(500);

    lightSleep();
    
    Serial.println("\tWaking up...");
    delay(500);
  }
  else{
    pump_status = false;

    // go to sleep
    // Serial.println("\tGoing to sleep...");
    // delay(500);

    // lightSleep();

    // Serial.println("\tWaking up...");
    // delay(500);
  }
}

void updateFirebase(){
  if (Firebase.ready() && signupOK && (millis() - sendDataPrevMillis > 10000 || sendDataPrevMillis == 0)){
  sendDataPrevMillis = millis();

  // Get Updated Trigger Level
  if (Firebase.RTDB.getString(&fbdo, "firebase-iot/live-data/update_trigger", updated_trigger)){
    Serial.println("\n\n");
    Serial.println("PULLED TRIGGER LEVEL FROM ANDROID");
    Serial.println("PATH: "+ fbdo.dataPath());
    Serial.println("TYPE: "+ fbdo.dataType());
  }
  else {
    Serial.println("\n\n");
    Serial.println("FAILED");
    Serial.println("REASON: "+ fbdo.errorReason());
  }

  // Moisture 
  if (Firebase.RTDB.setInt(&fbdo, "firebase-iot/live-data/moisture", moisture_percent)){
    Serial.println("\n\n");
    Serial.println("PASSED MOISTURE");
    Serial.println("PATH: "+ fbdo.dataPath());
    Serial.println("TYPE: "+ fbdo.dataType());
  }
  else {
    Serial.println("\n\n");
    Serial.println("FAILED");
    Serial.println("REASON: "+ fbdo.errorReason());
  }

  // Pump trigger
  if (Firebase.RTDB.setInt(&fbdo, "firebase-iot/live-data/pump_trigger", pump_trigger)){
    Serial.println("\n\n");
    Serial.println("PASSED TRIGGER LEVEL");
    Serial.println("PATH: "+ fbdo.dataPath());
    Serial.println("TYPE: "+ fbdo.dataType());
  }
  else {
    Serial.println("\n\n");
    Serial.println("FAILED");
    Serial.println("REASON: " + fbdo.errorReason());
  }

  // Pump status
  if (Firebase.RTDB.setInt(&fbdo, "firebase-iot/live-data/pump_status", pump_status)){
    Serial.println("\n\n");
    Serial.println("PASSED PUMP STATUS");
    Serial.println("PATH: " + fbdo.dataPath());
    Serial.println("TYPE: " + fbdo.dataType());
  }
  else {
    Serial.println("\n\n");
    Serial.println("FAILED");
    Serial.println("REASON: " + fbdo.errorReason());
  }
}
}

void updateTrigger(){
  if (updated_trigger == "")
  return;
  else {
  pump_trigger = std::stoi(updated_trigger);
  }
}

void getDHT(){
  temperature = dht.readTemperature();
  humidity = dht.readHumidity();
}

void lightSleep() {
    esp_sleep_enable_timer_wakeup(float(SLEEP_DURATION) * 1000000);
    esp_light_sleep_start();
}

void pumpOn(){
  Serial.println("turning motor on...");
  digitalWrite(MOTOR_PIN, HIGH);
  delay(3000);
}

void pumpOff(){
  Serial.println("turning motor off...");
  digitalWrite(MOTOR_PIN, LOW);
}